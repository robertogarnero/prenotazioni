import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {

  myForm: FormGroup;

  constructor(fb: FormBuilder) {
    this.myForm = fb.group({
      'nome': ['Nome', Validators.required],
      'email': ['Email', Validators.required],
      'data': ['gg/mm/2019', Validators.required],
      'ora': ['Ora', Validators.required]
    });
  }

  ngOnInit() {
  }
}